<?php
header("Access-Control-Allow-Origin:*");

// include mysql database configuration file
include_once 'db.php';
//fetch table rows from mysql db
$sql = "DELETE FROM users WHERE id = ". $_GET["id"];
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));


//close the db connection
mysqli_close($conn);

?>