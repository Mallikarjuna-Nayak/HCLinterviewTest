<?php
/* header("Access-Control-Allow-Origin:*");
header("Content-Type: application/json; charset=UTF-8"); */
header("Access-Control-Allow-Origin:*");   
header("Content-Type: application/json; charset=UTF-8");    
header("Access-Control-Allow-Methods: POST, DELETE, OPTIONS");    
header("Access-Control-Max-Age: 3600");    
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"); 

// include mysql database configuration file
include_once 'db.php';
//fetch table rows from mysql db
$sql = "select * from users where id = ".$_GET['id'];
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

//create an array
$emparray = array();
while($row =mysqli_fetch_assoc($result))
{
	$emparray[] = $row;
	
}
echo json_encode(["success"=>1,"data"=>$emparray]);

//echo '{"success":1,"data":[{"id":"1","name":"Mallikarjuna","email":"test1@gmail.com","phone":"9876543210","created_at":"2023-02-27 02:05:57","updated_at":"2023-02-27 02:02:32","status":"Active"},{"id":"2","name":"Mallikarjuna","email":"test2@gmail.com","phone":"9876543210","created_at":"2023-02-27 02:05:57","updated_at":"2023-02-27 02:02:32","status":"Active"},{"id":"3","name":"Mallikarjuna","email":"test3@gmail.com","phone":"9876543210","created_at":"2023-02-27 02:05:57","updated_at":"2023-02-27 02:02:33","status":"Active"},{"id":"4","name":"Mallikarjuna","email":"test4@gmail.com","phone":"9876543210","created_at":"2023-02-27 02:05:57","updated_at":"2023-02-27 02:02:33","status":"Active"},{"id":"5","name":"Mallikarjuna","email":"test@gmail.com","phone":"9876543210","created_at":"2023-02-27 02:05:57","updated_at":"2023-02-27 02:05:57","status":"Active"}]}';

//close the db connection
mysqli_close($conn);

?>